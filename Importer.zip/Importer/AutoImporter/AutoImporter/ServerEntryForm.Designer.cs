﻿namespace AutoImporter
{
    partial class ServerEntryForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.cmdProcessData = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.cmdBrowseFolder = new System.Windows.Forms.Button();
            this.txtFolderPath = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtCommonPassword = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.cmbTargetPlatform = new System.Windows.Forms.ComboBox();
            this.rdCompatibilityRules = new System.Windows.Forms.RadioButton();
            this.rdRecommendations = new System.Windows.Forms.RadioButton();
            this.cmdShowLogs = new System.Windows.Forms.Button();
            this.ServerName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UserName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Password = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WindowsLogin = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.CommonPassword = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Databases = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ServerName,
            this.UserName,
            this.Password,
            this.WindowsLogin,
            this.CommonPassword,
            this.Databases});
            this.dataGridView1.Location = new System.Drawing.Point(22, 42);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(683, 206);
            this.dataGridView1.TabIndex = 4;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.dataGridView1.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick);
            this.dataGridView1.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dataGridView1_CellFormatting);
            this.dataGridView1.CellStateChanged += new System.Windows.Forms.DataGridViewCellStateChangedEventHandler(this.dataGridView1_CellStateChanged);
            this.dataGridView1.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dataGridView1_EditingControlShowing);
            // 
            // cmdProcessData
            // 
            this.cmdProcessData.Location = new System.Drawing.Point(512, 257);
            this.cmdProcessData.Name = "cmdProcessData";
            this.cmdProcessData.Size = new System.Drawing.Size(163, 24);
            this.cmdProcessData.TabIndex = 1;
            this.cmdProcessData.Text = "Process and Import Data";
            this.cmdProcessData.UseVisualStyleBackColor = true;
            this.cmdProcessData.Click += new System.EventHandler(this.cmdProcessData_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(38, -20);
            this.textBox1.Name = "textBox1";
            this.textBox1.PasswordChar = '*';
            this.textBox1.Size = new System.Drawing.Size(139, 20);
            this.textBox1.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(-65, -17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Common Password";
            // 
            // folderBrowserDialog1
            // 
            this.folderBrowserDialog1.RootFolder = System.Environment.SpecialFolder.MyComputer;
            // 
            // cmdBrowseFolder
            // 
            this.cmdBrowseFolder.Location = new System.Drawing.Point(354, 15);
            this.cmdBrowseFolder.Name = "cmdBrowseFolder";
            this.cmdBrowseFolder.Size = new System.Drawing.Size(84, 23);
            this.cmdBrowseFolder.TabIndex = 10;
            this.cmdBrowseFolder.Text = "Browse Folder";
            this.cmdBrowseFolder.UseVisualStyleBackColor = true;
            this.cmdBrowseFolder.Click += new System.EventHandler(this.cmdBrowseFolder_Click);
            // 
            // txtFolderPath
            // 
            this.txtFolderPath.Location = new System.Drawing.Point(98, 15);
            this.txtFolderPath.Name = "txtFolderPath";
            this.txtFolderPath.Size = new System.Drawing.Size(237, 20);
            this.txtFolderPath.TabIndex = 11;
            this.txtFolderPath.Validated += new System.EventHandler(this.txtFolderPath_Validated);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 18);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "Report Location";
            // 
            // txtCommonPassword
            // 
            this.txtCommonPassword.Location = new System.Drawing.Point(111, 261);
            this.txtCommonPassword.Name = "txtCommonPassword";
            this.txtCommonPassword.PasswordChar = '*';
            this.txtCommonPassword.Size = new System.Drawing.Size(144, 20);
            this.txtCommonPassword.TabIndex = 14;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 264);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(97, 13);
            this.label2.TabIndex = 13;
            this.label2.Text = "Common Password";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // cmbTargetPlatform
            // 
            this.cmbTargetPlatform.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTargetPlatform.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbTargetPlatform.FormattingEnabled = true;
            this.cmbTargetPlatform.Location = new System.Drawing.Point(455, 15);
            this.cmbTargetPlatform.Name = "cmbTargetPlatform";
            this.cmbTargetPlatform.Size = new System.Drawing.Size(151, 21);
            this.cmbTargetPlatform.TabIndex = 0;
            this.cmbTargetPlatform.Validated += new System.EventHandler(this.cmbTargetPlatform_Validated);
            // 
            // rdCompatibilityRules
            // 
            this.rdCompatibilityRules.AutoSize = true;
            this.rdCompatibilityRules.Location = new System.Drawing.Point(261, 262);
            this.rdCompatibilityRules.Name = "rdCompatibilityRules";
            this.rdCompatibilityRules.Size = new System.Drawing.Size(113, 17);
            this.rdCompatibilityRules.TabIndex = 15;
            this.rdCompatibilityRules.TabStop = true;
            this.rdCompatibilityRules.Text = "Compatibility Rules";
            this.rdCompatibilityRules.UseVisualStyleBackColor = true;
            // 
            // rdRecommendations
            // 
            this.rdRecommendations.AutoSize = true;
            this.rdRecommendations.Location = new System.Drawing.Point(393, 262);
            this.rdRecommendations.Name = "rdRecommendations";
            this.rdRecommendations.Size = new System.Drawing.Size(113, 17);
            this.rdRecommendations.TabIndex = 16;
            this.rdRecommendations.TabStop = true;
            this.rdRecommendations.Text = "Recommendations";
            this.rdRecommendations.UseVisualStyleBackColor = true;
            this.rdRecommendations.CheckedChanged += new System.EventHandler(this.rdRecommendations_CheckedChanged);
            // 
            // cmdShowLogs
            // 
            this.cmdShowLogs.Location = new System.Drawing.Point(620, 13);
            this.cmdShowLogs.Name = "cmdShowLogs";
            this.cmdShowLogs.Size = new System.Drawing.Size(84, 23);
            this.cmdShowLogs.TabIndex = 17;
            this.cmdShowLogs.Text = "Show Logs";
            this.cmdShowLogs.UseVisualStyleBackColor = true;
            this.cmdShowLogs.Click += new System.EventHandler(this.cmdShowLogs_Click);
            // 
            // ServerName
            // 
            this.ServerName.HeaderText = "ServerName";
            this.ServerName.Name = "ServerName";
            this.ServerName.Width = 200;
            // 
            // UserName
            // 
            this.UserName.HeaderText = "UserName";
            this.UserName.Name = "UserName";
            this.UserName.Width = 120;
            // 
            // Password
            // 
            this.Password.HeaderText = "Password";
            this.Password.Name = "Password";
            this.Password.Width = 120;
            // 
            // WindowsLogin
            // 
            this.WindowsLogin.HeaderText = "WindowsLogin";
            this.WindowsLogin.Name = "WindowsLogin";
            // 
            // CommonPassword
            // 
            this.CommonPassword.HeaderText = "CommonPassword";
            this.CommonPassword.Name = "CommonPassword";
            this.CommonPassword.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.CommonPassword.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // Databases
            // 
            this.Databases.HeaderText = "Databases";
            this.Databases.Name = "Databases";
            // 
            // ServerEntryForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(717, 290);
            this.Controls.Add(this.cmdShowLogs);
            this.Controls.Add(this.rdRecommendations);
            this.Controls.Add(this.rdCompatibilityRules);
            this.Controls.Add(this.cmbTargetPlatform);
            this.Controls.Add(this.txtCommonPassword);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtFolderPath);
            this.Controls.Add(this.cmdBrowseFolder);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.cmdProcessData);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.Name = "ServerEntryForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Upgrade Advisor";
            this.Load += new System.EventHandler(this.ServerEntryForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button cmdProcessData;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.Button cmdBrowseFolder;
        private System.Windows.Forms.TextBox txtFolderPath;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtCommonPassword;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.ComboBox cmbTargetPlatform;
        private System.Windows.Forms.RadioButton rdRecommendations;
        private System.Windows.Forms.RadioButton rdCompatibilityRules;
        private System.Windows.Forms.Button cmdShowLogs;
        private System.Windows.Forms.DataGridViewTextBoxColumn ServerName;
        private System.Windows.Forms.DataGridViewTextBoxColumn UserName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Password;
        private System.Windows.Forms.DataGridViewCheckBoxColumn WindowsLogin;
        private System.Windows.Forms.DataGridViewCheckBoxColumn CommonPassword;
        private System.Windows.Forms.DataGridViewTextBoxColumn Databases;
    }
}

