﻿namespace AutoImporter
{
    partial class frmLoader
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.chkListDatabases = new System.Windows.Forms.CheckedListBox();
            this.cmdOK = new System.Windows.Forms.Button();
            this.cmdCancel = new System.Windows.Forms.Button();
            this.lblDatabases = new System.Windows.Forms.Label();
            this.rdCheckAll = new System.Windows.Forms.RadioButton();
            this.rdUnCheckAll = new System.Windows.Forms.RadioButton();
            this.txtDatabaseName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // chkListDatabases
            // 
            this.chkListDatabases.CheckOnClick = true;
            this.chkListDatabases.Location = new System.Drawing.Point(7, 51);
            this.chkListDatabases.Name = "chkListDatabases";
            this.chkListDatabases.Size = new System.Drawing.Size(206, 244);
            this.chkListDatabases.TabIndex = 1;
            // 
            // cmdOK
            // 
            this.cmdOK.Location = new System.Drawing.Point(17, 300);
            this.cmdOK.Name = "cmdOK";
            this.cmdOK.Size = new System.Drawing.Size(75, 23);
            this.cmdOK.TabIndex = 4;
            this.cmdOK.Text = "OK";
            this.cmdOK.Click += new System.EventHandler(this.cmdOK_Click);
            // 
            // cmdCancel
            // 
            this.cmdCancel.Location = new System.Drawing.Point(113, 300);
            this.cmdCancel.Name = "cmdCancel";
            this.cmdCancel.Size = new System.Drawing.Size(75, 23);
            this.cmdCancel.TabIndex = 5;
            this.cmdCancel.Text = "Cancel";
            this.cmdCancel.Click += new System.EventHandler(this.cmdCancel_Click);
            // 
            // lblDatabases
            // 
            this.lblDatabases.AutoSize = true;
            this.lblDatabases.Location = new System.Drawing.Point(62, 228);
            this.lblDatabases.Name = "lblDatabases";
            this.lblDatabases.Size = new System.Drawing.Size(0, 13);
            this.lblDatabases.TabIndex = 6;
            // 
            // rdCheckAll
            // 
            this.rdCheckAll.AutoSize = true;
            this.rdCheckAll.Location = new System.Drawing.Point(17, 7);
            this.rdCheckAll.Name = "rdCheckAll";
            this.rdCheckAll.Size = new System.Drawing.Size(70, 17);
            this.rdCheckAll.TabIndex = 7;
            this.rdCheckAll.TabStop = true;
            this.rdCheckAll.Text = "Check All";
            this.rdCheckAll.UseVisualStyleBackColor = true;
            this.rdCheckAll.CheckedChanged += new System.EventHandler(this.rdCheckAll_CheckedChanged);
            // 
            // rdUnCheckAll
            // 
            this.rdUnCheckAll.AutoSize = true;
            this.rdUnCheckAll.Location = new System.Drawing.Point(113, 7);
            this.rdUnCheckAll.Name = "rdUnCheckAll";
            this.rdUnCheckAll.Size = new System.Drawing.Size(84, 17);
            this.rdUnCheckAll.TabIndex = 8;
            this.rdUnCheckAll.TabStop = true;
            this.rdUnCheckAll.Text = "UnCheck All";
            this.rdUnCheckAll.UseVisualStyleBackColor = true;
            this.rdUnCheckAll.CheckedChanged += new System.EventHandler(this.rdUnCheckAll_CheckedChanged);
            // 
            // txtDatabaseName
            // 
            this.txtDatabaseName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtDatabaseName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtDatabaseName.Location = new System.Drawing.Point(57, 30);
            this.txtDatabaseName.Name = "txtDatabaseName";
            this.txtDatabaseName.Size = new System.Drawing.Size(157, 20);
            this.txtDatabaseName.TabIndex = 9;
            this.txtDatabaseName.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtDatabaseName_KeyDown);
            this.txtDatabaseName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDatabaseName_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(4, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "Database";
            // 
            // frmLoader
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(218, 328);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtDatabaseName);
            this.Controls.Add(this.rdUnCheckAll);
            this.Controls.Add(this.rdCheckAll);
            this.Controls.Add(this.lblDatabases);
            this.Controls.Add(this.cmdCancel);
            this.Controls.Add(this.cmdOK);
            this.Controls.Add(this.chkListDatabases);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmLoader";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Database List";
            this.Load += new System.EventHandler(this.frmLoader_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckedListBox chkListDatabases;
        private System.Windows.Forms.Button cmdOK;
        private System.Windows.Forms.Button cmdCancel;
        private System.Windows.Forms.Label lblDatabases;
        private System.Windows.Forms.RadioButton rdCheckAll;
        private System.Windows.Forms.RadioButton rdUnCheckAll;
        private System.Windows.Forms.TextBox txtDatabaseName;
        private System.Windows.Forms.Label label1;
    }
}