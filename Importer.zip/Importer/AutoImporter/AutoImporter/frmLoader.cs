﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AutoImporter
{

    public partial class frmLoader : Form
    {
        public static DataTable DatabaseValues;
        public static DataTable CheckedDatabaseValues;
		
        public frmLoader()
        {
            InitializeComponent();
        }

        private void frmLoader_Load(object sender, EventArgs e)
        {
            ((ListBox)chkListDatabases).DataSource = DatabaseValues;
            ((ListBox)chkListDatabases).DisplayMember = "Name";
            ((ListBox)chkListDatabases).ValueMember = "Name";
            rdCheckAll.Checked = true;
            rdCheckAll_CheckedChanged(sender, e);
            if (CheckedDatabaseValues != null)
            {


                for (int j = 0; j < chkListDatabases.Items.Count; j++)
                {
                    for (int i = 0; i < CheckedDatabaseValues.Rows.Count; i++)
                    {
                        string compareText = CheckedDatabaseValues.Rows[i][0].ToString();
                        DataRowView dr = (DataRowView)chkListDatabases.Items[j];
                        if (dr["name"].ToString() == compareText)
                        {
                            chkListDatabases.SetItemCheckState(j, CheckState.Checked);


                        }
                    }

                }

            }


            AutoCompleteStringCollection SCollection = new AutoCompleteStringCollection();
            for (int k = 0; k < DatabaseValues.Rows.Count; k++)
            {
                SCollection.Add(DatabaseValues.Rows[k]["name"].ToString());
            }

            txtDatabaseName.AutoCompleteCustomSource = SCollection;
        }

        private void pictureBox_Click(object sender, EventArgs e)
        {

        }

        private void cmdCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cmdOK_Click(object sender, EventArgs e)
        {

            StringBuilder items = new StringBuilder();
            foreach (var item in chkListDatabases.CheckedItems)
            {
                DataRowView dr = (DataRowView)item;
                items.Append("'" + dr["name"] + "'").Append(",");
            }
            ServerEntryForm.optionaldatabasename = "and name in (" + items.ToString().TrimEnd(',') + ")";
            this.Close();


        }

        private void rdCheckAll_CheckedChanged(object sender, EventArgs e)
        {
            for (int j = 0; j < chkListDatabases.Items.Count; j++)
            {
                chkListDatabases.SetItemCheckState(j, CheckState.Checked);

            }

        }

        private void rdUnCheckAll_CheckedChanged(object sender, EventArgs e)
        {

            for (int j = 0; j < chkListDatabases.Items.Count; j++)
            {
                chkListDatabases.SetItemCheckState(j, CheckState.Unchecked);

            }
        }

        private void txtDatabaseName_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void txtDatabaseName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                for (int i = 0; i < chkListDatabases.Items.Count; i++)
                {
                    string compareText = txtDatabaseName.Text.ToLower();
                    DataRowView dr = (DataRowView)chkListDatabases.Items[i];

                    if (dr["name"].ToString().ToLower().ToString().Contains(compareText))
                    {

                        chkListDatabases.SetSelected(i,true);

                    }
                }
            }
        }
    }
}
