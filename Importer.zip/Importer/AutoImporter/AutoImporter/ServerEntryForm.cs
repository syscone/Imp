﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using Microsoft.VisualBasic.FileIO;
using System.Diagnostics;
using System.Windows.Forms;

namespace AutoImporter
{
    public partial class ServerEntryForm : Form
    {
        Boolean IsWindowsLogin = false;
        public static string optionaldatabasename = "";
        public static int rowindex = -1;
        public ServerEntryForm()
        {
            InitializeComponent();
        }


        private void cmdProcessData_Click(object sender, EventArgs e)
        {

            if (txtFolderPath.Text == "")
            {
                errorProvider1.SetError(txtFolderPath, "Please enter a valid path");
                return;
            }
            if (cmbTargetPlatform.SelectedIndex == 0)
            {
                errorProvider1.SetError(cmbTargetPlatform, "Please select target platform");
                cmbTargetPlatform.Focus();
                return;
            }
            //frmLoader frm = new frmLoader();
            //frm.ShowDialog();
            foreach (DataGridViewRow gridrow in dataGridView1.Rows)
            {
                DataGridViewCheckBoxCell cell = gridrow.Cells[4] as DataGridViewCheckBoxCell;
                if (cell.Value != null)
                {
                    if (cell.Value.ToString() == "True" && txtCommonPassword.Text == "")
                    {
                        MessageBox.Show("Please enter a common password as column Common Password has been checked", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        txtCommonPassword.Focus();
                        return;
                    }
                }
            }
            int cnt = 1;
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                DataGridViewCheckBoxCell cell = row.Cells[3] as DataGridViewCheckBoxCell;

                if (cell.Value != null)
                {
                    if (cell.Value.ToString() == "True")
                    {
                        IsWindowsLogin = true;
                    }
                }

                if (row.Cells[0].Value == null || row.Cells[1].Value == null || row.Cells[2].Value == null)
                {
                    MessageBox.Show("Please enter all the mandatory information in the grid", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (row.Cells[5].Value == null)
                {

                    MigrationWizard(row.Cells[0].Value.ToString(), row.Cells[1].Value.ToString(), row.Cells[2].Value.ToString(), cmbTargetPlatform.Text, "");
                }
                else
                {
                    MigrationWizard(row.Cells[0].Value.ToString(), row.Cells[1].Value.ToString(), row.Cells[2].Value.ToString(), cmbTargetPlatform.Text, row.Cells[5].Value.ToString());

                }
                IsWindowsLogin = false;
                optionaldatabasename = "";
                if (cnt == dataGridView1.Rows.Count - 1) { break; }
                cnt++;
            }

            New();
            MessageBox.Show("All Data Processed and Imported successfully !!!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Close();


        }
        private DataTable ReturnDatabaseName(string ServerName, string UserName, string Password, string databasenames)
        {

            string connectionstring = "";
            if (IsWindowsLogin == true)
            {
                connectionstring = "Server= " + ServerName + ";Database=master;Trusted_Connection = yes;";
            }

            if (IsWindowsLogin == false)
            {
                connectionstring = "Server= " + ServerName + ";Database=master; User Id = " + UserName + "; Pwd = " + Password;

            }
            using (var connection = new System.Data.SqlClient.SqlConnection(connectionstring))
            {
                connection.Open();
                var command = new System.Data.SqlClient.SqlCommand();
                command.Connection = connection;
                command.CommandType = CommandType.Text;

                command.CommandText = "SELECT name FROM master.sys.databases where database_id>4 " + databasenames + " order by name";
                var adapter = new System.Data.SqlClient.SqlDataAdapter(command);
                var dataset = new DataSet();
                adapter.Fill(dataset);
                DataTable dtDatabases = dataset.Tables[0];
                return dtDatabases;
            }

        }

        public void MigrationWizard(string Server, string UserName, string Password, string TargetPlatform, string databasenames)
        {
            try
            {
                Process scriptProc = new Process();
                string str = "";
                // string database = "AdventureWorks"; string UserId = "sa"; string Password = "P@ssw0rd";
                DataTable dt = ReturnDatabaseName(Server, UserName, Password, databasenames);

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    this.Text = "Processing Server " + Server + " and Database " + dt.Rows[i]["name"];
                    scriptProc.StartInfo.FileName = @"DmaCmd.exe";
                    scriptProc.StartInfo.WorkingDirectory = @"C:\Program Files\Microsoft Data Migration Assistant\";
                    //  scriptProc.StartInfo.Arguments = @"/AssessmentName=""TestAssessment"" /AssessmentDatabases=""Server =  192.168.1.104\sqlserver2016; Initial Catalog = AdventureWorks; User Id = sa; Password = P@ssw0rd;"" /AssessmentTargetPlatform=""SQLServer2016"" /AssessmentEvaluateCompatibilityIssues /AssessmentOverwriteResult /AssessmentResultCsv=""E:\Sachin\New\AssessmentReport.csv"" /AssessmentResultJson=""E:\Sachin\New\test2016.json""";
                    if (UserName != "" && Password != "")
                    {
                        if (rdCompatibilityRules.Checked == true && TargetPlatform == "SqlServer2016")
                        {
                            str = @"/AssessmentName=""TestAssessment"" /AssessmentDatabases="" Server = " + Server + ";";
                            str = str + "Initial Catalog=" + dt.Rows[i]["name"] + "; User Id= " + UserName + ";Password =" + Password + ";";
                            str = str + @"""";
                            str = str + @" /AssessmentTargetPlatform=""" + TargetPlatform + @"""";
                            str = str + @" /AssessmentEvaluateCompatibilityIssues /AssessmentOverwriteResult /AssessmentResultCsv=""" + txtFolderPath.Text + "\\" + dt.Rows[i]["name"].ToString() + "_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".csv" + @"""" + "";
                        }

                        if (rdRecommendations.Checked == true && TargetPlatform == "SqlServer2016")
                        {
                            str = @"/AssessmentName=""TestAssessment"" /AssessmentDatabases="" Server = " + Server + ";";
                            str = str + "Initial Catalog=" + dt.Rows[i]["name"] + "; User Id= " + UserName + ";Password =" + Password + ";";
                            str = str + @"""";
                            str = str + @" /AssessmentTargetPlatform=""" + TargetPlatform + @"""";
                            str = str + @" /AssessmentEvaluateRecommendations /AssessmentOverwriteResult /AssessmentResultCsv=""" + txtFolderPath.Text + "\\" + dt.Rows[i]["name"].ToString() + "_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".csv" + @"""" + "";
                        }

                        if (rdCompatibilityRules.Checked == true && TargetPlatform == "AzureSqlDatabaseV12")
                        {
                            str = @"/AssessmentName=""TestAssessment"" /AssessmentDatabases="" Server = " + Server + ";";
                            str = str + "Initial Catalog=" + dt.Rows[i]["name"] + "; User Id= " + UserName + ";Password =" + Password + ";";
                            str = str + @"""";
                            str = str + @" /AssessmentTargetPlatform=""" + TargetPlatform + @"""";
                            str = str + @" /AssessmentEvaluateCompatibilityIssues /AssessmentOverwriteResult /AssessmentResultCsv=""" + txtFolderPath.Text + "\\" + dt.Rows[i]["name"].ToString() + "_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".csv" + @"""" + "";
                        }

                        if (rdRecommendations.Checked == true && TargetPlatform == "AzureSqlDatabaseV12")
                        {
                            str = @"/AssessmentName=""TestAssessment"" /AssessmentDatabases="" Server = " + Server + ";";
                            str = str + "Initial Catalog=" + dt.Rows[i]["name"] + "; User Id= " + UserName + ";Password =" + Password + ";";
                            str = str + @"""";
                            str = str + @" /AssessmentTargetPlatform=""" + TargetPlatform + @"""";
                            str = str + @" /AssessmentEvaluateRecommendations /AssessmentEvaluateFeatureParity /AssessmentOverwriteResult /AssessmentResultCsv=""" + txtFolderPath.Text + "\\" + dt.Rows[i]["name"].ToString() + "_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".csv" + @"""" + "";
                        }

                    }

                    if (UserName == "" && Password == "")
                    {
                        if (rdCompatibilityRules.Checked == true && TargetPlatform == "SqlServer2016")
                        {
                            str = @"/AssessmentName=""TestAssessment"" /AssessmentDatabases="" Server = " + Server + ";";
                            str = str + "Initial Catalog=" + dt.Rows[i]["name"] + ";Integrated Security=true";
                            str = str + @"""";
                            str = str + @" /AssessmentTargetPlatform=""" + TargetPlatform + @"""";
                            str = str + @" /AssessmentEvaluateCompatibilityIssues /AssessmentOverwriteResult /AssessmentResultCsv=""" + txtFolderPath.Text + "\\" + dt.Rows[i]["name"].ToString() + "_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".csv" + @"""" + "";
                        }

                        if (rdRecommendations.Checked == true && TargetPlatform == "SqlServer2016")
                        {
                            str = @"/AssessmentName=""TestAssessment"" /AssessmentDatabases="" Server = " + Server + ";";
                            str = str + "Initial Catalog=" + dt.Rows[i]["name"] + ";Integrated Security=true";
                            str = str + @"""";
                            str = str + @" /AssessmentTargetPlatform=""" + TargetPlatform + @"""";
                            str = str + @" /AssessmentEvaluateRecommendations /AssessmentOverwriteResult /AssessmentResultCsv=""" + txtFolderPath.Text + "\\" + dt.Rows[i]["name"].ToString() + "_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".csv" + @"""" + "";
                        }

                        if (rdCompatibilityRules.Checked == true && TargetPlatform == "AzureSqlDatabaseV12")
                        {
                            str = @"/AssessmentName=""TestAssessment"" /AssessmentDatabases="" Server = " + Server + ";";
                            str = str + "Initial Catalog=" + dt.Rows[i]["name"] + ";Integrated Security=true";
                            str = str + @"""";
                            str = str + @" /AssessmentTargetPlatform=""" + TargetPlatform + @"""";
                            str = str + @" /AssessmentEvaluateCompatibilityIssues /AssessmentOverwriteResult /AssessmentResultCsv=""" + txtFolderPath.Text + "\\" + dt.Rows[i]["name"].ToString() + "_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".csv" + @"""" + "";
                        }

                        if (rdRecommendations.Checked == true && TargetPlatform == "AzureSqlDatabaseV12")
                        {
                            str = @"/AssessmentName=""TestAssessment"" /AssessmentDatabases="" Server = " + Server + ";";
                            str = str + "Initial Catalog=" + dt.Rows[i]["name"] + ";Integrated Security=true";
                            str = str + @"""";
                            str = str + @" /AssessmentTargetPlatform=""" + TargetPlatform + @"""";
                            str = str + @" /AssessmentEvaluateRecommendations /AssessmentEvaluateFeatureParity /AssessmentOverwriteResult /AssessmentResultCsv=""" + txtFolderPath.Text + "\\" + dt.Rows[i]["name"].ToString() + "_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".csv" + @"""" + "";
                        }

                    }
                    scriptProc.StartInfo.Arguments = str;
                    scriptProc.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                    scriptProc.Start();
                    scriptProc.WaitForExit();
                    scriptProc.Close();
                }
            }
            catch (System.IO.DirectoryNotFoundException ex2)
            {
                errorProvider1.SetError(txtFolderPath, "The directory does not exist." +
                    "Try again with a different directory.");
            }
        }


        private void New()
        {

            string subPath = txtFolderPath.Text + "\\Archive";

            bool exists = System.IO.Directory.Exists(subPath);

            if (!exists)
                System.IO.Directory.CreateDirectory(subPath);

            string con = ConfigurationManager.ConnectionStrings["con"].ToString();
            SqlConnection connection = new SqlConnection(con);
            connection.Open();
            var commandStr = "If not exists (select name from sysobjects where name = 'UpgradeCumulatedValues') CREATE TABLE UpgradeCumulatedValues([File Name] varchar(max),[Server Name] varchar(max),[Server Version] varchar(max),[Database Name] varchar(max),Status varchar(max),Description varchar(max))";
            using (SqlCommand command = new SqlCommand(commandStr, connection))
                command.ExecuteNonQuery();

            commandStr = "If not exists (select name from sysobjects where name = 'UpgradeCompatibility') CREATE TABLE UpgradeCompatibility([File Name] varchar(max),[Server Name] varchar(max),[Server Version] varchar(max),[Database Name] varchar(max),Issue varchar(max),[Source Compatibility Level] varchar(max),[Impact] varchar(max),[Target Compatibility Level] varchar(max),[Compatibility Category] varchar(max),[Recommendation] varchar(max),[More Info] varchar(max),[Impacted Object Type] varchar(max),[Impacted Object] varchar(max),[Impacted Object Details] varchar(max))";
            using (SqlCommand command = new SqlCommand(commandStr, connection))
                command.ExecuteNonQuery();

            commandStr = "If not exists (select name from sysobjects where name = 'UpgradeParity') CREATE TABLE UpgradeParity([File Name] varchar(max),[Server Name] varchar(max),[Server Version] varchar(max),[Feature Parity Category] varchar(max),[Impacted Database] varchar(max),[Impacted Database Details] varchar(max),[Issue] varchar(max),[Recommendation] varchar(max),[Additional Reading] varchar(max))";
            using (SqlCommand command = new SqlCommand(commandStr, connection))
                command.ExecuteNonQuery();

            commandStr = "If not exists (select name from sysobjects where name = 'UpgradeRecommendations') CREATE TABLE UpgradeRecommendations([File Name] varchar(max),[Server Name] varchar(max),[Server Version] varchar(max),[Database] varchar(max),[Focus Area] varchar(max),[Recommended Object Type] varchar(max),[Recommended Object Name] varchar(max),[Recommended Object Details] varchar(max),[Issue] varchar(max),[Severity] varchar(max),[Recommendation] varchar(max),[Additional Reading] varchar(max))";
            using (SqlCommand command = new SqlCommand(commandStr, connection))
                command.ExecuteNonQuery();

            DataTable dt1 = new DataTable();
            DataTable dt2 = new DataTable();
            DataTable dt3 = new DataTable();
            DataTable dt4 = new DataTable();

            dt1.Columns.AddRange(new DataColumn[6] {
                        new DataColumn("[File Name]", typeof(string)),
                        new DataColumn("[Server Name]", typeof(string)),
                        new DataColumn("[Server Version]", typeof(string)),
                        new DataColumn("[Database Name]", typeof(string)),
                        new DataColumn("Status", typeof(string)),
                        new DataColumn("Description",typeof(string))
                    });

            dt2.Columns.AddRange(new DataColumn[14] {
                        new DataColumn("[File Name]", typeof(string)),
                        new DataColumn("[Server Name]", typeof(string)),
                        new DataColumn("[Server Version]", typeof(string)),
                        new DataColumn("[Database Name]", typeof(string)),
                        new DataColumn("Issue", typeof(string)),
                        new DataColumn("[Source Compatibility Level]",typeof(string)),
                        new DataColumn("[Impact]",typeof(string)),
                        new DataColumn("[Target Compatibility Level]",typeof(string)),
                        new DataColumn("[Compatibility Category]",typeof(string)),
                        new DataColumn("[Recommendation]",typeof(string)),
                        new DataColumn("[More Info]",typeof(string)),
                        new DataColumn("[Impacted Object Type]",typeof(string)),
                        new DataColumn("[Impacted Object]",typeof(string)),
                        new DataColumn("[Impacted Object Details]",typeof(string))
                    });

            dt3.Columns.AddRange(new DataColumn[9] {
                        new DataColumn("[File Name]", typeof(string)),
                        new DataColumn("[Server Name]", typeof(string)),
                        new DataColumn("[Server Version]", typeof(string)),
                        new DataColumn("[Feature Parity Category]", typeof(string)),
                        new DataColumn("[Impacted Database]", typeof(string)),
                        new DataColumn("[Impacted Database Details]",typeof(string)),
                        new DataColumn("[Issue]",typeof(string)),
                        new DataColumn("[Recommendation]",typeof(string)),
                        new DataColumn("[Additional Reading]",typeof(string))
                    });

            dt4.Columns.AddRange(new DataColumn[12]{
                        new DataColumn("[File Name]", typeof(string)),
                        new DataColumn("[Server Name]", typeof(string)),
                        new DataColumn("[Server Version]", typeof(string)),
                        new DataColumn("[Database Name]", typeof(string)),
                        new DataColumn("[Focus Area]", typeof(string)),
                        new DataColumn("[Recommended Object Type]", typeof(string)),
                        new DataColumn("[Recommended Object Name]",typeof(string)),
                        new DataColumn("[Recommended Object Details]",typeof(string)),
                        new DataColumn("[Issue]",typeof(string)),
                        new DataColumn("[Severity]",typeof(string)),
                        new DataColumn("[Recommendation]",typeof(string)),
                        new DataColumn("[Additional Reading]",typeof(string))
                    });

            string[] extensions = { "csv" };

            string[] dizin = Directory.GetFiles(txtFolderPath.Text, "*.*")
                .Where(f => extensions.Contains(f.Split('.').Last().ToLower())).ToArray();

            // var filePaths = System.IO.Directory.GetFiles(ConfigurationManager.AppSettings["Path"], "*_*.csv");
            foreach (string file in dizin)
            {
                TextFieldParser prs = new TextFieldParser(file);
                prs.TextFieldType = FieldType.Delimited;
                prs.SetDelimiters(",");
                int i = -1; int j = -1; ; int k = -1; int l = -1;
                Boolean resume = false;
                while (!prs.EndOfData)
                {
                    string[] flds = prs.ReadFields();
                    foreach (string fls in flds)
                    {
                        if (fls.Contains("Assessment Execution Summary - Server Instances"))
                        { goto Outer1; }

                        if (fls.ToString().Contains("Feature Parity"))
                        { goto Outer2; }

                        if (fls.ToString().Contains("Feature Recommendations"))
                        { goto Outer3; }

                        if (fls == "Assessment Execution Summary - Databases")
                        {
                            resume = true;
                        }

                        if (resume == false)
                        { continue; }

                        if (resume == true)
                        {
                            if (fls == "Assessment Execution Summary - Databases")
                            { continue; }

                            dt1.Rows.Add();
                            dt1.Rows[dt1.Rows.Count - 1][0] = file;
                            dt1.Rows[dt1.Rows.Count - 1][1] = flds[0];
                            dt1.Rows[dt1.Rows.Count - 1][2] = flds[1];
                            dt1.Rows[dt1.Rows.Count - 1][3] = flds[2];
                            dt1.Rows[dt1.Rows.Count - 1][4] = flds[3];
                            dt1.Rows[dt1.Rows.Count - 1][5] = flds[4];
                            break;
                        }

                        j++;

                    }
                }

            Outer1://Database Compatibility Issues
                resume = false;
                while (!prs.EndOfData)
                {
                    string[] flds = prs.ReadFields();

                    foreach (string fld in flds)
                    {
                        if (fld.ToString().Contains("Feature Parity"))
                        { goto Outer2; }

                        if (fld.ToString().Contains("Feature Recommendations"))
                        { goto Outer3; }


                        if (fld == "Database Compatibility Issues")
                        {
                            resume = true;
                        }

                        if (resume == false)
                        { continue; }

                        if (i > 7 && resume == true)
                        {
                            if (fld == "Database Compatibility Issues")
                            { continue; }
                            dt2.Rows.Add();
                            dt2.Rows[dt2.Rows.Count - 1][0] = file;
                            dt2.Rows[dt2.Rows.Count - 1][1] = flds[0];
                            dt2.Rows[dt2.Rows.Count - 1][2] = flds[1];
                            dt2.Rows[dt2.Rows.Count - 1][3] = flds[2];
                            dt2.Rows[dt2.Rows.Count - 1][4] = flds[3];
                            dt2.Rows[dt2.Rows.Count - 1][5] = flds[4];
                            dt2.Rows[dt2.Rows.Count - 1][6] = flds[5];
                            dt2.Rows[dt2.Rows.Count - 1][7] = flds[6];
                            dt2.Rows[dt2.Rows.Count - 1][8] = flds[7];
                            dt2.Rows[dt2.Rows.Count - 1][9] = flds[8];
                            dt2.Rows[dt2.Rows.Count - 1][10] = flds[9];
                            dt2.Rows[dt2.Rows.Count - 1][11] = flds[10];
                            dt2.Rows[dt2.Rows.Count - 1][12] = flds[11];
                            dt2.Rows[dt2.Rows.Count - 1][13] = flds[12];
                            break;
                        }
                        i++;
                    }

                }

            Outer2://Parity
                resume = false;
                while (!prs.EndOfData)
                {


                    string[] fldg = prs.ReadFields();
                    foreach (string fld in fldg)
                    {
                        if (fld.ToString().Contains("Feature Parity"))
                        { continue; }

                        if (fld.ToString().Contains("Feature Recommendations"))
                        { goto Outer3; }

                        dt3.Rows.Add();
                        dt3.Rows[dt3.Rows.Count - 1][0] = file;
                        dt3.Rows[dt3.Rows.Count - 1][1] = fldg[0];
                        dt3.Rows[dt3.Rows.Count - 1][2] = fldg[1];
                        dt3.Rows[dt3.Rows.Count - 1][3] = fldg[2];
                        dt3.Rows[dt3.Rows.Count - 1][4] = fldg[3];
                        dt3.Rows[dt3.Rows.Count - 1][5] = fldg[4];
                        dt3.Rows[dt3.Rows.Count - 1][6] = fldg[5];
                        dt3.Rows[dt3.Rows.Count - 1][7] = fldg[6];
                        dt3.Rows[dt3.Rows.Count - 1][8] = fldg[7];

                        break;
                    }
                    k++;
                }


            Outer3://Recommendations
                resume = false;
                while (!prs.EndOfData)
                {
                    string[] flgs = prs.ReadFields();
                    foreach (string fld in flgs)
                    {
                        if (fld.ToString().Contains("Feature Parity"))
                        { goto Outer2; }

                        if (fld.ToString().Contains("Feature Recommendations"))
                        { continue; }

                        dt4.Rows.Add();
                        dt4.Rows[dt4.Rows.Count - 1][0] = file;
                        dt4.Rows[dt4.Rows.Count - 1][1] = flgs[0];
                        dt4.Rows[dt4.Rows.Count - 1][2] = flgs[1];
                        dt4.Rows[dt4.Rows.Count - 1][3] = flgs[2];
                        dt4.Rows[dt4.Rows.Count - 1][4] = flgs[3];
                        dt4.Rows[dt4.Rows.Count - 1][5] = flgs[4];
                        dt4.Rows[dt4.Rows.Count - 1][6] = flgs[5];
                        dt4.Rows[dt4.Rows.Count - 1][7] = flgs[6];
                        dt4.Rows[dt4.Rows.Count - 1][8] = flgs[7];
                        dt4.Rows[dt4.Rows.Count - 1][9] = flgs[8];
                        dt4.Rows[dt4.Rows.Count - 1][10] = flgs[9];
                        dt4.Rows[dt4.Rows.Count - 1][11] = flgs[10];
                        break;
                    }
                    l++;
                }


                using (var cons = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ToString()))
                {
                    cons.Open();
                    using (System.Data.SqlClient.SqlBulkCopy sqlBulkCopy = new SqlBulkCopy(cons))
                    {

                        sqlBulkCopy.DestinationTableName = "dbo.UpgradeCumulatedValues";
                        sqlBulkCopy.WriteToServer(dt1);

                        sqlBulkCopy.DestinationTableName = "dbo.UpgradeCompatibility";
                        sqlBulkCopy.WriteToServer(dt2);

                        //Azure Recommendation Feature Parity
                        sqlBulkCopy.DestinationTableName = "dbo.UpgradeParity";
                        sqlBulkCopy.WriteToServer(dt3);

                        //SQL 2016 Recommendation Feature Recommendations
                        sqlBulkCopy.DestinationTableName = "dbo.UpgradeRecommendations";
                        sqlBulkCopy.WriteToServer(dt4);

                        cons.Close();
                    }
                }
                prs.Close();
                prs.Dispose();
                System.IO.File.Move(file, subPath + "\\" + file.Split('\\').Last());
               // connection.Open();
                var cmd = "Delete from UpgradeRecommendations where [Server Name]='Server Name';Delete from UpgradeCompatibility where [Server Name]='Server Name';Delete from UpgradeCumulatedValues where [Server Name]='Server Name';Delete from UpgradeParity where [Server Name]='Server Name';";
                using (SqlCommand command = new SqlCommand(cmd, connection))
                    command.ExecuteNonQuery();
                connection.Close();

            }

        }


        static void Old()
        {
            string con = ConfigurationManager.ConnectionStrings["con"].ToString();
            SqlConnection connection = new SqlConnection(con);
            connection.Open();
            var commandStr = "If not exists (select name from sysobjects where name = 'UpgradeAdvisor') CREATE TABLE UpgradeAdvisor(Server varchar(max),[DataBase] varchar(max),[File Name] varchar(max),Issue varchar(max),[Database Compat Level] varchar(max),[Object Affected] varchar(max),[Rule Title] varchar(max),[Impact] varchar(max),[Recommendation] varchar(max),[Rule Category] varchar(max),[Severity] varchar(max))";

            using (SqlCommand command = new SqlCommand(commandStr, connection))
                command.ExecuteNonQuery();

            var filePaths = System.IO.Directory.GetFiles(ConfigurationManager.AppSettings["Path"], "*_*.csv");

            foreach (string s in filePaths)
            {
                string[] filename = s.Split('\\');
                filename = filename[2].Split('.');
                string database = filename[1];
                using (System.IO.StreamReader sr = new StreamReader(s))
                {

                    DataTable dt = new DataTable();
                    dt.Columns.AddRange(new DataColumn[12] {
                        new DataColumn("Server", typeof(string)),
                        new DataColumn("[DataBase]", typeof(string)),
                        new DataColumn("[FileName]", typeof(string)),
                        new DataColumn("Issue", typeof(string)),
                        new DataColumn("[Database Compat Level]",typeof(string)),
                        new DataColumn("[Object Affected]",typeof(string)),
                        new DataColumn("[Rule Id]",typeof(string)),
                        new DataColumn("[Rule Title]",typeof(string)),
                        new DataColumn("[Impact]",typeof(string)),
                        new DataColumn("[Recommendation]",typeof(string)),
                        new DataColumn("[Rule Category]",typeof(string)),
                        new DataColumn("[Severity]",typeof(string))
                    });


                    string csvData = File.ReadAllText(s);
                    foreach (string row in csvData.Split('\n'))
                    {
                        if (!string.IsNullOrEmpty(row))
                        {
                            if (row.Contains("No issues found") || row == "")
                            { continue; }

                            if (row.Contains("Issue"))
                            { continue; }

                            dt.Rows.Add();
                            int i = 3;
                            foreach (string cell in row.Split(','))
                            {
                                if (i == 11)
                                { continue; }
                                dt.Rows[dt.Rows.Count - 1][0] = ConfigurationManager.AppSettings["Server"];
                                dt.Rows[dt.Rows.Count - 1][1] = database;
                                dt.Rows[dt.Rows.Count - 1][2] = s;
                                dt.Rows[dt.Rows.Count - 1][i] = cell;
                                i++;
                            }
                        }
                    }



                    using (var cons = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ToString()))
                    {
                        cons.Open();
                        using (System.Data.SqlClient.SqlBulkCopy sqlBulkCopy = new SqlBulkCopy(cons))
                        {
                            //Set the database table name
                            sqlBulkCopy.DestinationTableName = "dbo.UpgradeAdvisor";

                            sqlBulkCopy.WriteToServer(dt);
                            cons.Close();
                        }
                    }

                }
            }


        }



        private void dataGridView1_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {


        }

        private void dataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.ColumnIndex == 2 && e.Value != null)
            {

                e.Value = new String('*', e.Value.ToString().Length);
            }
        }

        private void dataGridView1_CellStateChanged(object sender, DataGridViewCellStateChangedEventArgs e)
        {
            //foreach (DataGridViewRow row in dataGridView1.Rows)
            //{
            //    DataGridViewCheckBoxCell chk = row.Cells[4] as DataGridViewCheckBoxCell;
            //    if (chk != null)
            //    {
            //        if (Convert.ToBoolean(chk.Value) == true)
            //            MessageBox.Show("this cell checked");
            //        e.Cell[2].
            //        break;
            //    }
            //}

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                DataGridViewCheckBoxCell checkbox = (DataGridViewCheckBoxCell)dataGridView1.CurrentCell;

                if (checkbox != null)
                {
                    bool isChecked = (bool)checkbox.EditedFormattedValue;
                    if (isChecked == true && e.ColumnIndex == 3)
                    {
                        dataGridView1.CurrentRow.Cells[1].ReadOnly = true;
                        dataGridView1.CurrentRow.Cells[2].ReadOnly = true;
                        dataGridView1.CurrentRow.Cells[1].Style.BackColor = System.Drawing.Color.Gray;
                        dataGridView1.CurrentRow.Cells[2].Style.BackColor = System.Drawing.Color.Gray;
                        dataGridView1.CurrentRow.Cells[1].Value = "";
                        dataGridView1.CurrentRow.Cells[2].Value = "";
                        dataGridView1.CurrentRow.Cells[4].ReadOnly = true;
                        IsWindowsLogin = true;

                    }
                    if (isChecked == false && e.ColumnIndex == 3)
                    {

                        dataGridView1.CurrentRow.Cells[1].ReadOnly = false;
                        dataGridView1.CurrentRow.Cells[2].ReadOnly = false;
                        dataGridView1.CurrentRow.Cells[1].Style.BackColor = System.Drawing.Color.White;
                        dataGridView1.CurrentRow.Cells[2].Style.BackColor = System.Drawing.Color.White;
                        dataGridView1.CurrentRow.Cells[4].ReadOnly = false;
                        IsWindowsLogin = false;
                    }
                    if (isChecked == true && e.ColumnIndex == 4)
                    {
                        dataGridView1.CurrentRow.Cells[2].Value = txtCommonPassword.Text;
                        dataGridView1.CurrentRow.Cells[2].ReadOnly = true;
                        dataGridView1.CurrentRow.Cells[3].ReadOnly = true;

                    }
                    if (isChecked == false && e.ColumnIndex == 4)
                    {
                        dataGridView1.CurrentRow.Cells[2].ReadOnly = false;
                        dataGridView1.CurrentRow.Cells[3].ReadOnly = false;

                    }
                }
            }
            catch (Exception ex)
            {

            }
        }

        private void ServerEntryForm_Load(object sender, EventArgs e)
        {
            cmbTargetPlatform.Focus();
            cmbTargetPlatform.Items.Add("Target Platform");
            cmbTargetPlatform.Items.Add("AzureSqlDatabaseV12");
            cmbTargetPlatform.Items.Add("SqlServer2016");
            cmbTargetPlatform.SelectedIndex = 0;
            rdCompatibilityRules.Checked = true;

        }

        private void cmdBrowseFolder_Click(object sender, EventArgs e)
        {
            DialogResult result = folderBrowserDialog1.ShowDialog();
            if (result == DialogResult.OK)
            {

                txtFolderPath.Text = folderBrowserDialog1.SelectedPath;
            }
        }

        private void txtFolderPath_Validated(object sender, EventArgs e)
        {

            errorProvider1.SetError(txtFolderPath, "");
            return;
        }

        private void cmbTargetPlatform_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(cmbTargetPlatform, "");
            return;
        }

        private void rdRecommendations_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == -1)
            {
                rowindex = e.RowIndex;
                if (dataGridView1[0, rowindex].Value == null || dataGridView1[1, e.RowIndex].Value == null || dataGridView1[2, e.RowIndex].Value == null)
                {
                    MessageBox.Show("Please enter all the mandatory information in the grid", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                frmLoader frm = new frmLoader();
                frm.Closed += new EventHandler(frm_FormClosed);
                DataTable dtdatabase = new DataTable();

                DataGridViewCheckBoxCell ch1 = new DataGridViewCheckBoxCell();
                ch1 = (DataGridViewCheckBoxCell)dataGridView1.Rows[dataGridView1.CurrentRow.Index].Cells[3];

                //if (ch1.Value == null)
                //    ch1.Value = false;
                //switch (ch1.Value.ToString())
                //{
                //    case "True":
                //        IsWindowsLogin = true;
                //        break;
                //    case "False":
                //        IsWindowsLogin = false;
                //        break;
                //}


                if (dataGridView1[5, rowindex].Value == null)
                {
                    frmLoader.DatabaseValues = ReturnDatabaseName(dataGridView1[0, e.RowIndex].Value.ToString(), dataGridView1[1, e.RowIndex].Value.ToString(), dataGridView1[2, e.RowIndex].Value.ToString(), string.Empty);
                }
                else
                {

                    frmLoader.DatabaseValues = ReturnDatabaseName(dataGridView1[0, e.RowIndex].Value.ToString(), dataGridView1[1, e.RowIndex].Value.ToString(), dataGridView1[2, e.RowIndex].Value.ToString(), string.Empty);
                    frmLoader.CheckedDatabaseValues = ReturnDatabaseName(dataGridView1[0, e.RowIndex].Value.ToString(), dataGridView1[1, e.RowIndex].Value.ToString(), dataGridView1[2, e.RowIndex].Value.ToString(), dataGridView1[5, e.RowIndex].Value.ToString());
                }
                frm.ShowDialog();

            }
        }



        private void frm_FormClosed(object sender, EventArgs e)
        {
            dataGridView1[5, rowindex].Value = optionaldatabasename;
        }

        private void cmdShowLogs_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(Environment.GetEnvironmentVariable("LocalAppData") + "\\DataMigrationAssistant\\" + @"dma.log"); ;
        }
    }
}
